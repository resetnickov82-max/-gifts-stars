#!/usr/bin/env bash
set -euo pipefail

# Build helper for Linux/macOS. Install Android Studio or command-line tools first,
# then ensure ANDROID_HOME (or ANDROID_SDK_ROOT), sdkmanager, and Gradle are available.
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$SDK_ROOT" ]]; then
  echo "Android SDK not found. Install Android SDK command-line tools and set ANDROID_HOME or ANDROID_SDK_ROOT." >&2
  exit 1
fi
if ! command -v sdkmanager >/dev/null 2>&1; then
  echo "sdkmanager is not on PATH. Add the Android SDK cmdline-tools/latest/bin directory to PATH." >&2
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not on PATH. Install Gradle or build with Android Studio / GitHub Actions." >&2
  exit 1
fi
sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"
cd "$(dirname "$0")"
gradle --no-daemon assembleDebug
echo "APK created at: app/build/outputs/apk/debug/app-debug.apk"
