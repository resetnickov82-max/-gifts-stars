# Gift's Stars Android wrapper

This Android Studio project wraps `app/src/main/assets/index.html` in a WebView and uses the app icon as the launcher icon. It is a source project, not a precompiled APK.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `android` folder in Android Studio and allow Gradle sync.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

The demo/arcade UI can run locally. Google login, Telegram authentication, shared cloud leaderboard and live gift data require the deployed HTTPS backend/Firebase and bot configuration described in the root README. The local app does not grant ownership of Telegram gifts.
