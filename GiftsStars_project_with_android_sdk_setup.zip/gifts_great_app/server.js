import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import admin from 'firebase-admin';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const WEB_ORIGIN = process.env.WEB_ORIGIN || '';
const MAX_AUTH_AGE_SECONDS = Number(process.env.TELEGRAM_AUTH_MAX_AGE_SECONDS || 86400);

if (!admin.apps.length) admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  projectId: process.env.FIREBASE_PROJECT_ID || 'botstars-580f9'
});
const firebaseAuth = admin.auth();
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false, crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' }, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
if (WEB_ORIGIN) {
  const allowed = WEB_ORIGIN.split(',').map(s => s.trim()).filter(Boolean);
  app.use(cors({ origin(origin, cb) { if (!origin || allowed.includes(origin)) return cb(null, true); return cb(new Error('Origin not allowed')); } }));
}
app.use(express.json({ limit: '24kb' }));
const authLimiter = rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: true, legacyHeaders: false });
const giftsLimiter = rateLimit({ windowMs: 60_000, limit: 50, standardHeaders: true, legacyHeaders: false });

function requireBotToken(_req, res, next) {
  if (!BOT_TOKEN) return res.status(503).json({ error: 'telegram_api_not_configured', message: 'Set TELEGRAM_BOT_TOKEN on the server.' });
  next();
}
async function telegram(method, payload = {}) {
  if (!BOT_TOKEN) throw new Error('TELEGRAM_BOT_TOKEN is not configured');
  const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload), signal: AbortSignal.timeout(15000)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.description || `Telegram API ${method} failed`);
  return data.result;
}
function validateTelegramInitData(initData) {
  if (!BOT_TOKEN) throw new Error('Telegram login is not configured on the server');
  if (typeof initData !== 'string' || initData.length < 10 || initData.length > 16000) throw new Error('Missing Telegram init data');
  const params = new URLSearchParams(initData);
  const receivedHash = params.get('hash');
  if (!receivedHash || !/^[a-f0-9]{64}$/i.test(receivedHash)) throw new Error('Telegram hash is missing');
  // Telegram's bot-token validation format: all fields sorted by key, excluding hash.
  const checkString = [...params.entries()].filter(([key]) => key !== 'hash').sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${key}=${value}`).join('\n');
  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
  const calculatedHash = crypto.createHmac('sha256', secretKey).update(checkString).digest('hex');
  const got = Buffer.from(receivedHash, 'hex');
  const expected = Buffer.from(calculatedHash, 'hex');
  if (got.length !== expected.length || !crypto.timingSafeEqual(got, expected)) throw new Error('Telegram signature is invalid');
  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || authDate <= 0 || Math.floor(Date.now() / 1000) - authDate > MAX_AUTH_AGE_SECONDS || authDate - Math.floor(Date.now() / 1000) > 60) throw new Error('Telegram session is expired');
  const rawUser = params.get('user');
  if (!rawUser) throw new Error('Telegram user is missing');
  const user = JSON.parse(rawUser);
  if (!Number.isSafeInteger(Number(user.id)) || Number(user.id) <= 0 || user.is_bot) throw new Error('Invalid Telegram user');
  return { id: Number(user.id), first_name: String(user.first_name || ''), last_name: String(user.last_name || ''), username: String(user.username || ''), photo_url: String(user.photo_url || ''), language_code: String(user.language_code || '') };
}
const availableGiftCache = { at: 0, gifts: [] };
async function getGiftCatalog(force = false) {
  const now = Date.now();
  if (!force && availableGiftCache.gifts.length && now - availableGiftCache.at < 60_000) return availableGiftCache.gifts;
  const result = await telegram('getAvailableGifts');
  const gifts = Array.isArray(result.gifts) ? result.gifts : [];
  availableGiftCache.at = now;
  availableGiftCache.gifts = gifts;
  return gifts;
}
function imageRoute(fileId) { return `/api/gifts/image/${encodeURIComponent(fileId)}`; }
function mapCatalogGift(gift) {
  const sticker = gift.sticker || {};
  return {
    id: String(gift.id),
    name: `Telegram Gift ${String(gift.id).slice(-5)}`,
    stars: Number.isFinite(Number(gift.star_count)) ? Number(gift.star_count) : null,
    remaining: gift.remaining_count ?? gift.personal_remaining_count ?? null,
    limited: gift.total_count != null,
    unique: Number(gift.unique_gift_variant_count || 0) > 0,
    imageUrl: sticker.file_id ? imageRoute(sticker.file_id) : null,
    fileId: sticker.file_id || null
  };
}
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'gifts-great-api', telegramConfigured: Boolean(BOT_TOKEN) }));
app.post('/api/auth/telegram', authLimiter, requireBotToken, async (req, res) => {
  try {
    const user = validateTelegramInitData(req.body?.initData);
    const uid = `tg_${user.id}`;
    const customToken = await firebaseAuth.createCustomToken(uid, { telegramId: user.id, authProvider: 'telegram' });
    return res.json({ customToken, user: { id: user.id, firstName: user.first_name, lastName: user.last_name, username: user.username, photoUrl: user.photo_url, languageCode: user.language_code } });
  } catch (error) {
    return res.status(401).json({ error: 'telegram_auth_failed', message: error.message || 'Could not validate Telegram login.' });
  }
});
app.get('/api/gifts', giftsLimiter, requireBotToken, async (_req, res) => {
  try {
    const gifts = await getGiftCatalog();
    res.set('Cache-Control', 'public, max-age=30');
    res.json({ gifts: gifts.map(mapCatalogGift) });
  } catch (error) {
    res.status(502).json({ error: 'telegram_catalog_failed', message: error.message });
  }
});
// Images are resolved from sticker file IDs only if they belong to the live gift catalog or a server-fetched owned collection.
const permittedStickerFiles = new Set();
app.get('/api/gifts/image/:fileId', giftsLimiter, requireBotToken, async (req, res) => {
  try {
    const fileId = String(req.params.fileId || '');
    if (!fileId || fileId.length > 500 || !/^[A-Za-z0-9_=.\-]+$/.test(fileId)) return res.status(400).end();
    if (!permittedStickerFiles.has(fileId)) {
      const gifts = await getGiftCatalog();
      for (const gift of gifts) if (gift.sticker?.file_id) permittedStickerFiles.add(gift.sticker.file_id);
      if (!permittedStickerFiles.has(fileId)) return res.status(404).end();
    }
    const file = await telegram('getFile', { file_id: fileId });
    if (!file.file_path || file.file_path.endsWith('.tgs') || file.file_path.endsWith('.webm')) return res.status(415).end();
    const telegramFileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
    const upstream = await fetch(telegramFileUrl, { signal: AbortSignal.timeout(15000) });
    if (!upstream.ok) return res.status(502).end();
    const type = upstream.headers.get('content-type') || (file.file_path.endsWith('.webp') ? 'image/webp' : 'application/octet-stream');
    res.set('Content-Type', type); res.set('Cache-Control', 'public, max-age=3600');
    res.send(Buffer.from(await upstream.arrayBuffer()));
  } catch (error) { res.status(502).end(); }
});
async function requireFirebaseUser(req, res, next) {
  const match = /^Bearer\s+(.+)$/i.exec(req.get('authorization') || '');
  if (!match) return res.status(401).json({ error: 'missing_bearer_token' });
  try { req.firebaseUser = await firebaseAuth.verifyIdToken(match[1]); next(); }
  catch { return res.status(401).json({ error: 'invalid_firebase_token' }); }
}
app.get('/api/my-gifts', giftsLimiter, requireBotToken, requireFirebaseUser, async (req, res) => {
  try {
    const telegramId = Number(req.firebaseUser.telegramId);
    if (!Number.isSafeInteger(telegramId) || telegramId <= 0 || req.firebaseUser.uid !== `tg_${telegramId}`) return res.status(403).json({ error: 'telegram_account_required', message: 'Sign in using Telegram Mini App to view this account’s gift collection.' });
    const result = await telegram('getUserGifts', { user_id: telegramId, limit: 100 });
    const catalog = await getGiftCatalog();
    const catalogById = new Map(catalog.map(g => [String(g.id), mapCatalogGift(g)]));
    const gifts = (result.gifts || []).map((owned, index) => {
      const gift = owned.gift || owned;
      const baseId = String(gift.gift_id || gift.id || '');
      const base = catalogById.get(baseId);
      const unique = owned.type === 'unique';
      const stickerFileId = gift.sticker?.file_id || base?.fileId || null;
      if (stickerFileId) permittedStickerFiles.add(stickerFileId);
      return { id: String(gift.id || baseId || `owned-${index}`), name: unique ? String(gift.name || gift.base_name || 'Telegram Collectible') : (base?.name || 'Telegram Gift'), type: owned.type || (unique ? 'unique' : 'regular'), unique, stars: base?.stars ?? null, imageUrl: stickerFileId ? imageRoute(stickerFileId) : (base?.imageUrl || null) };
    });
    res.json({ gifts, total: Number(result.total_count || gifts.length) });
  } catch (error) { res.status(502).json({ error: 'gift_inventory_failed', message: error.message }); }
});
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res, next) => { if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'not_found' }); res.sendFile(path.join(__dirname, 'public', 'index.html'), err => { if (err) next(err); }); });
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'server_error' }); });
app.listen(PORT, () => console.log(`Gifts Great listening on http://localhost:${PORT}`));
