# Gifts Great — Arcade + Telegram Gifts

Mobile-first web app inspired by the screenshots: blue space grid, animated rocket flight, neon chest gallery, animated gift-preview roulette, profile, progress, tasks, daily XP, promo demo, sound and UA/RU localization.

## Safety / functionality boundary

- Crash has a virtual-points arcade mode: a player can stake demo points, cash out during a flight, or lose only those virtual points if the rocket crashes first. Points have no cash value and cannot be converted into money or Telegram Stars.
- The full case gallery includes the original themed collections plus Rolex, Ocean, Cosmic, Neon, Mystery and Legends. Case roulette remains a visual preview; it does not spend Stars or award real gifts from a random result.
- The gift catalog is read from Telegram Bot API after the backend is configured. It is informational; the app does not buy or send gifts.
- Telegram gift catalog availability is not the same as owning a collectible/NFT. Unique gifts depend on what the Telegram API returns for the authenticated user's account. Telegram's Bot API has `getAvailableGifts` and `getUserGifts`; sending gifts is a separate operation and may spend the bot's balance.

## Run locally (visual demo)

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Run `npm install` and then `npm start`.
4. Open `http://localhost:3000` and tap **Переглянути демо**.

The demo works without Telegram credentials, but it shows illustrative artwork instead of live gift images. Firebase/Google authentication needs a deployed HTTPS origin; `file://` is not supported for real login.

## Enable Google login + saved profile

The frontend currently uses the Firebase Web config from the existing project (`botstars-580f9`). In Firebase Console:

1. Authentication → Sign-in method → enable **Google**.
2. Add the deployed HTTPS domain under Authentication → Settings → Authorized domains.
3. Create/enable Cloud Firestore and apply the rules from `firestore.rules`.

Only per-user profile progress is written by the client. Never store passwords in localStorage. Review the Firebase project's provider and domain configuration before public launch.

## Enable Telegram Mini App login + real gift catalog

1. Create/use your Telegram bot via `@BotFather`; keep its token secret.
2. Add `TELEGRAM_BOT_TOKEN` to the server's `.env`.
3. Configure Firebase Admin credentials on the server using Application Default Credentials or `GOOGLE_APPLICATION_CREDENTIALS` pointing to a service-account JSON file kept outside public web files. Do not upload that JSON to the static folder or ZIP publicly.
4. Set the actual bot username in `public/index.html` at `TELEGRAM_BOT_USERNAME` (without `@`).
5. Deploy to HTTPS, configure the Mini App URL through `@BotFather`, and use the bot to open the app.
6. Use `/api/health` to check the server and `/api/gifts` to check the live catalog.

The backend verifies Telegram `initData` with the bot token and issues a Firebase custom token. It does not trust `initDataUnsafe` as proof of identity. It also proxies gift sticker images so the bot token is never sent to the browser. `/api/my-gifts` reads the signed-in Telegram user's gift list through Bot API; Google-only accounts cannot request someone else's Telegram collection.

## Deploy notes

- Keep `.env`, service-account credentials, and the bot token private. Do not commit them or place them in `public/`.
- Set `WEB_ORIGIN` when you host the frontend on a different origin, for example `https://your-app.example`.
- Apply Firestore rules before enabling cloud profile writes.
- `getAvailableGifts` shows gifts the bot can send. It does not mean each item is a unique collectible. The app intentionally does not connect real gift sending to a random case/roulette outcome.


## Android app (Gift's Stars)

An Android Studio WebView wrapper is included in `android/`, with the app name **Gift's Stars** and a blue Telegram-Star-inspired launcher icon. The Android SDK is not bundled inside this ZIP because it is a large development toolchain and does not belong inside the app itself. The GitHub Actions workflow automatically installs the Android SDK Platform 35 and Build Tools 35.0.0 on its temporary build machine. For a local computer build, install Android Studio (including Android SDK Platform 35) and run `android/build-apk.sh` in a terminal, or use the Android Studio Build menu. This workspace cannot produce the APK directly here because Android SDK/Gradle are not installed in this environment. The output is normally `android/app/build/outputs/apk/debug/app-debug.apk`.

## Virtual points and leaderboard

Crash stakes use only local/demo points; they are not real money, crypto, or Telegram Stars. Authenticated users can sync their profile and score to Firestore. Apply the updated `firestore.rules` in Firebase Console to enable signed-in leaderboard reads and per-user writes. Demo users only have local records. Client-side scores are not anti-cheat protected; a production public leaderboard should submit results to a trusted server for validation.

## Build APK in GitHub Actions (without Android Studio on your phone)
1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab and select **Build Gift's Stars APK**.
3. Tap **Run workflow** and wait for the green check.
4. Open the completed run and download the `GiftsStars-debug-apk` artifact. Extract the ZIP to get `app-debug.apk` and install it on Android (you may need to allow installs from that file manager).

This creates a debug APK for testing, not a Play Store release. Keep signing keys and API secrets out of the repository.
